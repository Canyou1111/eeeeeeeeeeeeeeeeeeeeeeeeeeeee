setblock ~ ~-1 ~ endergetic:crystal_holder
tag @s add obsidian
