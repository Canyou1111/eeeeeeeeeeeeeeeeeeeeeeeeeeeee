execute as @a at @s in the_end if entity @s[advancements={endergizedendisland:utility/end_gateway=true}] run schedule function endergizedendisland:end_gateway/replace_end_gateways 2t
execute as @a at @s in the_end if entity @s[advancements={endergizedendisland:utility/end_gateway=true}] run advancement revoke @s only endergizedendisland:utility/end_gateway
