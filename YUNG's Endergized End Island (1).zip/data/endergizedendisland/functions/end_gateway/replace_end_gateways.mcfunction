execute as @a at @s in the_end if predicate endergizedendisland:end_gateway run place template betterendisland:gateway ~ ~-6 ~-1
