execute as @a at @s in the_end if score @s endergizedendisland.check_end_gateways matches 1 if predicate endergizedendisland:end_gateway run function endergizedendisland:end_gateway/replace_end_gateways

execute as @e[type=minecraft:end_crystal,nbt={ShowBottom:1b},tag=!bedrock] at @s in the_end if block ~ ~-1 ~ bedrock run function endergizedendisland:crystals/replace_bedrock
execute as @e[type=minecraft:end_crystal,nbt={ShowBottom:1b},tag=!obsidian] at @s in the_end if block ~ ~-1 ~ obsidian run function endergizedendisland:crystals/replace_obsidian
